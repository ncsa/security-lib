This folder contains some file and directories to test the VFS (virtual file system) capabilities of QDL. It is zipped and mounted during unit tests and the contents checked.
root
 |
 + - readme.txt (this file)
 |
 + scripts
 |    |
 |    + - armstrong_numbers.qdl
 |    + - messy_function.qdl
 |    + - hello_world.qdl  
 | 
 + - other
       |
       + - config.json
       |
       + - sub-folder1
                |
                + - math.txt
